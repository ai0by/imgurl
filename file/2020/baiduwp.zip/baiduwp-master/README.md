# baiduwp
PanDownload Web, built with CloudFlare Workers
# Demo
No longer available due to abuse.
# Usage
```
headers:{
    'user-agent': 'Some UA',
    'Cookie': 'BDUSS=INPUT YOUR BDUSS HERE; STOKEN=INPUT YOUR STOKEN HERE'
  }
```
# Thanks

[PanDownload](https://pandownload.com): static pages

[KinhDown](https://t.me/kinhdown): client type

[PNL](https://www.lanzous.com/u/pnl): download method

[acgotaku/BaiduExporter](https://github.com/acgotaku/BaiduExporter): send to aria2
